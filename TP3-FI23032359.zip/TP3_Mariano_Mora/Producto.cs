﻿using System;
using System.Collections.Generic;

namespace TP3_Mariano_Mora
{
    public class Producto
    {
        public int ProductoId { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaHora { get; set; }

        public virtual ICollection<Numero> Numeros { get; set; } = new List<Numero>();
    }
}
