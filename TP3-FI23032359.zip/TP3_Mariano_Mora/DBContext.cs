﻿using System.Data.Entity;

namespace TP3_Mariano_Mora
{
    public class TP3Context : DbContext
    {
        public TP3Context() : base("TP3Connection") { }

        public DbSet<Producto> Productos { get; set; }
        public DbSet<Numero> Numeros { get; set; }
    }
}
