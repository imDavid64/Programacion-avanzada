/// Para el codigo y resolucion de problemas que enfrente -> https://chatgpt.com/share/68588778-93a8-8011-be6a-fb7f0d8acdaa

///Para explicaciones puntuales del codigo ->
https://chatgpt.com/share/68588782-d05c-8011-98b5-c7cf3fb4e738