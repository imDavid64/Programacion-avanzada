﻿Select * FROM Numeroes
WHERE Numero

Select * FROM dbo.Numeroes
Where Num = 1;

