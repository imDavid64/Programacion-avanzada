﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TP3_Mariano_Mora
{
    class Program
    {
        static void Main()
        {
            using (var context = new TP3Context())
            {
                bool continuar = true;

                while (continuar)
                {
                    Console.Write("Escriba el nombre del producto: ");
                    string nombre = Console.ReadLine();

                    int cantidad;
                    do
                    {
                        Console.Write("Escriba la cantidad de números aleatorios a generar: ");
                    } while (!int.TryParse(Console.ReadLine(), out cantidad) || cantidad <= 0);

                    bool permitirRepetidos = true;

                    if (cantidad <= 100)
                    {
                        Console.Write("¿Los números se pueden repetir? (s/n): ");
                        string respuesta = Console.ReadLine().ToLower();
                        permitirRepetidos = respuesta == "s";
                    }

                    var producto = new Producto
                    {
                        Nombre = nombre,
                        FechaHora = DateTime.Now
                    };

                    HashSet<int> generados = new HashSet<int>();
                    Random rnd = new Random();

                    for (int i = 1; i <= cantidad;)
                    {
                        int num = rnd.Next(0, 100);

                        if (permitirRepetidos || generados.Add(num))
                        {
                            producto.Numeros.Add(new Numero
                            {
                                Orden = i,
                                Num = num
                            });
                            i++;
                        }
                    }

                    context.Productos.Add(producto);

                    Console.Write("¿Desea agregar otro producto? (s/n): ");
                    string continuarRespuesta = Console.ReadLine().ToLower();
                    continuar = continuarRespuesta == "s";

                    if (!continuar)
                    {
                        context.SaveChanges();

                        Console.WriteLine("\n=== Productos registrados ===\n");

                        var productos = context.Productos
                            .OrderBy(p => p.FechaHora)
                            .ToList();

                        foreach (var prod in productos)
                        {
                            Console.WriteLine($"Producto ID: {prod.ProductoId}, Nombre: {prod.Nombre}, Fecha: {prod.FechaHora}");

                            foreach (var numero in prod.Numeros.OrderBy(n => n.Orden))
                            {
                                Console.WriteLine($"\tNúmero ID: {numero.NumeroId}, Orden: {numero.Orden}, Valor: {numero.Num}");
                            }

                            Console.WriteLine();
                        }

                        Console.WriteLine("Programa finalizado. Presione cualquier tecla para salir.");
                        Console.ReadKey();
                    }
                }
            }
        }
    }
}
